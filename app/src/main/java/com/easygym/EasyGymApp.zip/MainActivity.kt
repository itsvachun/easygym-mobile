package com.easygym

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.easygym.ui.theme.EasyGymTheme
import androidx.compose.foundation.isSystemInDarkTheme
import com.easygym.ui.navigation.NavGraph
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            EasyGymTheme(darkTheme = isSystemInDarkTheme()) {
                NavGraph()
            }
        }
    }
}
